<footer class="site-footer">
  <div class="footer-content">
    <p>&copy; <?php echo date('Y'); ?> Godinez Music. All rights reserved.</p>
    <div class="social-icons">
      <a href="https://www.facebook.com/danny.godinez.96" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/icons/square-facebook-brands.svg" alt="Facebook"></a>
      <a href="https://www.instagram.com/dannygodinezguitar/" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/icons/instagram-brands 2.svg" alt="Instagram"></a>
      <a href="https://www.youtube.com/watch?v=CrWJmF7BXAM&list=PLJPMYJBMIetC68tMeGftHNSGks7xJBu7P" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/icons/square-youtube-brands.svg" alt="YouTube"></a>
      <a href="https://soundcloud.com/annyodinez" target="_blank"><img src="<?php echo get_template_directory_uri(); ?>/icons/soundcloud-brands 1.svg" alt="Soundcloud"></a>
  </div>

  <!-- YouTube Modal -->
  <div id="videoModal" class="modal">
    <div class="modal-content">
      <span class="close">&times;</span>
      <iframe src="" frameborder="0" allowfullscreen></iframe>
    </div>
  </div>

  <?php wp_footer(); ?>
  <script src="<?php echo get_template_directory_uri(); ?>/js/youtubeModal.js"></script>
  <script src="<?php echo get_template_directory_uri(); ?>/js/nav.js"></script>
</footer>
</body>
</html>