<?php
function godinez_enqueue_assets() {
  wp_enqueue_style('godinez-style', get_stylesheet_uri());
  wp_enqueue_script('godinez-nav', get_template_directory_uri() . '/nav.js', array(), null, true);
}
add_action('wp_enqueue_scripts', 'godinez_enqueue_assets');

function godinez_register_event_post_type() {
  register_post_type('event', [
    'labels' => [
      'name' => 'Events',
      'singular_name' => 'Event'
    ],
    'public' => true,
    'has_archive' => false,
    'menu_icon' => 'dashicons-calendar',
    'supports' => ['title', 'editor', 'excerpt'],
    'show_in_rest' => true
  ]);
}
add_action('init', 'godinez_register_event_post_type');
?>
