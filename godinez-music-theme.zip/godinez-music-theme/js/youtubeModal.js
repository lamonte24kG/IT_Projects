/*YouTube Modal */
// YouTube Modal
document.addEventListener("DOMContentLoaded", function () {
    const modals = document.querySelectorAll(".modal");
    const thumbnails = document.querySelectorAll(".video-thumbnail");
  
    // Open modal
    thumbnails.forEach(thumbnail => {
      thumbnail.addEventListener("click", function () {
        const videoId = this.getAttribute("data-video");
        const modal = document.getElementById("videoModal");
        const iframe = modal.querySelector("iframe");
  
        if (videoId) {
          modal.classList.add("active");
          iframe.src = `https://www.youtube.com/embed/${videoId}?autoplay=1`;
        }
      });
    });
  
    // Close modal with close button
    document.querySelectorAll(".modal .close").forEach(btn => {
      btn.addEventListener("click", function () {
        const modal = this.closest(".modal");
        const iframe = modal.querySelector("iframe");
        modal.classList.remove("active");
        if (iframe) iframe.src = "";
      });
    });
  
    // Close modal when clicking outside content
    window.addEventListener("click", function (event) {
      modals.forEach(modal => {
        if (event.target === modal) {
          modal.classList.remove("active");
          const iframe = modal.querySelector("iframe");
          if (iframe) iframe.src = "";
        }
      });
    });
  
    // Ensure all modals are hidden initially
    modals.forEach(modal => modal.classList.remove("active"));
  });