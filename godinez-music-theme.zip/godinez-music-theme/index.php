<?php get_header(); ?>

<main id="main-content">
    <section id="hero" class="hero-banner">
      <img src="http://localhost:8888/DGM/wp-content/uploads/2025/05/danny_hero_1024-1.jpg" alt="Godinez Hero" class="hero-image">
      <div class="hero-overlay">
        <h1>Godinez Music</h1>
        <p>Feel the rhythm. Live the sound.</p>
      </div>
    </section>



  <section id="events">
    <h2>Upcoming Events</h2>
    <div class="events-list">
      <?php
        $today = date('Ymd');

      $events = new WP_Query([
        'post_type'      => 'event',
        'posts_per_page' => -1, // Show all upcoming events
        'meta_key'       => 'event_date',
        'orderby'        => 'meta_value_num', // more reliable than 'meta_value'
        'order'          => 'ASC',
        'meta_query'     => [
          [
            'key'     => 'event_date',
            'value'   => $today,
            'compare' => '>=',
            'type'    => 'NUMERIC'
          ]
        ]
      ]);

        if ($events->have_posts()) :
          while ($events->have_posts()) : $events->the_post(); ?>
            <div class="event">
              <h3><?php the_title(); ?></h3>
              <p><strong>Date:</strong> 
                <?php 
                  $raw_date = get_field('event_date');
                  $formatted_date = DateTime::createFromFormat('Ymd', $raw_date)->format('m/d/Y');
                  echo $formatted_date;
                  ?>
              <p><strong>Time:</strong> <?php the_field('time'); ?></p>
              <p><strong>Location:</strong> <?php the_field('location'); ?></p>
              <p><?php the_field('description'); ?></p>
              <?php if ($link = get_field('link')) : ?>
                <p><strong>More Info:</strong> <a href="<?php echo esc_url($link); ?>" target="_blank" rel="noopener noreferrer">
                  <?php echo esc_html($link); ?>
                </a></p>
              <?php endif; ?>
            </div>
          <?php endwhile;
          wp_reset_postdata();
        else :
          echo '<p>No upcoming events.</p>';
        endif;
      ?>
    </div>
  </section>

  <section id="music">
    <h2>Music</h2>
    <?php echo do_shortcode('[ai_playlist id="53"]'); ?>
  </section>

  <!-- <section id="videos">
    <h2>Videos</h2>
    <div class="video-grid">
      
      <div class="video">
        <div class="video-wrapper">
          <iframe src="https://www.youtube.com/embed/xqfAiiXBMgs"
            title="YouTube video player" frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen></iframe>
        </div>
      </div>

      <div class="video">
        <div class="video-wrapper">
          <iframe src="https://www.youtube.com/embed/WVbVWv8OJWY"
            title="YouTube video player" frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen></iframe>
        </div>
      </div>

      <div class="video">
        <div class="video-wrapper">
          <iframe src="https://www.youtube.com/embed/hAQyNDJ0NPY"
            title="YouTube video player" frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen></iframe>
        </div>
      </div>

    </div>
  </section> -->

<section id="videos">
  <h2>Videos</h2>
  <div class="video-grid">

    <div class="video-thumbnail" data-video="xqfAiiXBMgs">
      <img src="https://img.youtube.com/vi/xqfAiiXBMgs/hqdefault.jpg" alt="Video 1">
    </div>

    <div class="video-thumbnail" data-video="WVbVWv8OJWY">
      <img src="https://img.youtube.com/vi/WVbVWv8OJWY/hqdefault.jpg" alt="Video 2">
    </div>

    <div class="video-thumbnail" data-video="hAQyNDJ0NPY">
      <img src="https://img.youtube.com/vi/hAQyNDJ0NPY/hqdefault.jpg" alt="Video 3">
    </div>

  </div>
</section>

  <section id="about">
    <h2>About</h2>
    <p>About section content.</p>
  </section>

  <section id="contact">
    <h2>Contact</h2>
    <?php echo do_shortcode('[wpforms id="112"]'); ?>
  </section>
</main>

<?php get_footer(); ?>
