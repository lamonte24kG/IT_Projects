<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php bloginfo('name'); ?><?php wp_title('|'); ?></title>
  <link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<div class="grid-container">
<header>
  <nav class="navbar">
    <a href="#hero" class="nav-branding" id="nav-logo">Godinez</a>

    <ul class="nav-menu">
      <li class="nav-item"><a href="#hero" class="nav-link">Home</a></li>
      <li class="nav-item"><a href="#events" class="nav-link">Events</a></li>
      <li class="nav-item"><a href="#music" class="nav-link">Music</a></li>
      <li class="nav-item"><a href="#videos" class="nav-link">Videos</a></li>
      <li class="nav-item"><a href="#about" class="nav-link">About</a></li>
      <li class="nav-item"><a href="#contact" class="nav-link">Contact</a></li>
    </ul>

    <div class="hamburger">
      <span class="bar"></span>
      <span class="bar"></span>
      <span class="bar"></span>
    </div>
  </nav>
</header>
